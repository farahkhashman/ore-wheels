cmake \
-D Python_ROOT_DIR=$PYTHON_ROOT_DIR \
-D ORE_USE_ZLIB=ON \
-D ORE=$ORE \
-D ORE_BUILD=$ORE_BUILD \
-G Ninja ..
