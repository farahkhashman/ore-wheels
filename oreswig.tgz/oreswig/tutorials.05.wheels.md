
# Managing Wheels

This document explains how to generate wheels for the ORE project.

[Back to tutorials index](tutorials.00.index.md)

# Prerequisites

## Github Actions

Below is the repo that we use to generate wheels with github actions.  You need
to clone the repo:

https://github.com/eehlers/ore-wheels.git

## Test pypi server

Below is the ORE project on the test pypi server.  You need to acquire access
rights to that project:

https://test.pypi.org/project/open-source-risk-engine/

## Prod pypi server

Below is the ORE project on the prod pypi server.  You need to acquire access
rights to that project:

https://pypi.org/project/open-source-risk-engine/

# Generating Source Tarballs

We need to upload the ORE and ORESWIG source to the GitHub Actions repo which
builds the wheels.  You need to do this twice: 1) zip files for Windows 2) tar
files for posix (macos/linux).  We generate the compressed files (zip and tar)
using python script `zip_files.py`.

## `zip_files.py`

Before running the script, you must ensure:

- That your local copies of the ORE and ORESWIG repos (and their submodules)
  are up to date
- That you have set the correct version number in file:
  `oreswig/OREAnalytics-SWIG/Python/setup.py`

You also need to set some environment variables, e.g.:

On windows:

    SET ORE_DIR=C:\repos\ore.github
    SET ORESWIG_DIR=C:\repos\oreswig.github
    SET SWIG_DIR=C:\repos\swigwin\swigwin-4.1.1
    SET PATH=%PATH%;%SWIG_DIR%

On posix:

    export ORE_DIR=/home/username/repos/ore.github
    export ORESWIG_DIR=/home/username/repos/oreswig.github

Now you are ready to run the script.  cd into the root directory of your
ore-wheels repo.  

## ORE

To compress the files for ORE and its submodules, do:

    zip_files.py -o

This generates a compressed file (`ore.zip` on windows, `ore.tgz` on posix)
which overwrites the relevant file in the current directory.  Now you must do a
git commit and push.

## ORESWIG

We do not install swig to the Github Actions Runner.  Instead, we use script
`zip_files.py` to perform the following actions:

- compress ORESWIG and its submodules
- uncompress the file, run the swig wrapper, and compress it again

To perform those actions, do:

    zip_files.py -s

This generates a compressed file (`oreswig.zip` on windows, `oreswig.tgz` on
posix) which overwrites the relevant file in the current directory.  Now you
must do a git commit and push.

# Generating the Wheels

Now go on to the ore-wheels repo on github and run the jobs to generate the
wheels.  Download the wheels to your hard drive.

# Uploading the Wheels

## twine

The upload command relies on twine, here are the commands to install twine:

    python -m pip install --upgrade pip
    python -m pip install --upgrade twine

Twine uses a configuration file to authenticate to the server.  On windows the
path to the file is:

    C:\Users\username\.pypirc

On posix the path to the file is:

    ~/.pypirc

The commands below assume that you have configured `test.pypi.og` as `test` and
`pypi.org` as `pypi`.

## Uploading Wheels to the Test Server

The test server for Python wheels is: https://test.pypi.org/project/open-source-risk-engine/

Here is the command to upload the wheels to the test server:

    python -m twine upload --repository test *.whl

Here is the command to install the wheel from the test server (run this within a virtual environment):

    pip install -i https://test.pypi.org/simple/ open-source-risk-engine

## Uploading Wheels to the Production Server

The production server for Python wheels is: https://pypi.org/project/open-source-risk-engine/

Here is the command to upload the wheels to the production server:

    python -m twine upload --repository pypi *.whl

Here is the command to install the wheel from the production server (run this within a virtual environment):

    pip install open-source-risk-engine

# Links

- [test pypi](https://test.pypi.org/)
- [prod pypi](https://pypi.org/)
- [Sharing Your Labor of Love: PyPI Quick and Dirty](https://hynek.me/articles/sharing-your-labor-of-love-pypi-quick-and-dirty/)
- [github actions runner images](https://github.com/actions/runner-images)
- [cibuildwheel](https://github.com/pypa/cibuildwheel)
- [manylinux](https://github.com/pypa/manylinux)
- [musllinux](https://wiki.musl-libc.org/projects-using-musl.html)

